class Main {
  public static void main(String[] args) {
    Administrator admin = new Administrator();

    try {
      admin.run(300);
    } catch(InterruptedException e) {
      
    }
  }
}
