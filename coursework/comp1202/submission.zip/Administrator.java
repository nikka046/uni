import java.util.UUID;

// runs school as a Simulation
class Administrator {
  private School school; // school that will be simulated
  private static Toolbox toolbox = new Toolbox(); // toolbox used to get random integer

  // constructor
  public Administrator() {
    school = new School("Simulated School");

    Subject basics = new Subject(1, 1, 5);
    Subject lab1 = new Subject(2, 2, 2);
    Subject arrays = new Subject(3, 1, 3);
    Subject algorithms = new Subject(4, 1, 1);
    Subject testing = new Subject(5, 1, 3);
    Subject lab2 = new Subject(6, 2, 2);
    Subject oo1 = new Subject(7, 3, 6);
    Subject oo2 = new Subject(8, 3, 7);
    Subject lab3 = new Subject(9, 2, 3);
    Subject graphics = new Subject(10, 4, 5);
    Subject controllers = new Subject(11, 4, 2);
    Subject lab4 = new Subject(12, 2, 3);
    
    school.add(basics);
    school.add(lab1);
    school.add(arrays);
    school.add(algorithms);
    school.add(testing);
    school.add(lab2);
    school.add(oo1);
    school.add(oo2);
    school.add(lab3);
    school.add(graphics);
    school.add(controllers);
    school.add(lab4);

    school.add(new Course(basics, 0));
    school.add(new Course(basics, 20));
    school.add(new Course(lab1, 2));
    school.add(new Course(lab1, 7));
    school.add(new Course(arrays, 7));
    school.add(new Course(arrays, 1));

    SimulationConfig.readFile("my");
  }

  // runs the simulation for 1 day
  public void run() {
    // generates a random number, either 1 or 2
    // indicates how manu new students will be added to the school
    Integer nOfNewStudents = toolbox.getRandomInteger(2);
    // generate and add given amount of students
    for (int i = 0; i < nOfNewStudents; i++) {
      school.add(generateStudent()); 
    }
    
    // generate a new instructor
    if (getProbability(20))
      school.add(new Teacher(randomName(), randomGender(), randomAge()));
    if (getProbability(10))
      school.add(new Demonstrator(randomName(), randomGender(), randomAge()));
    if (getProbability(20))
      school.add(new OOTrainer(randomName(), randomGender(), randomAge()));
    if (getProbability(20))
      school.add(new GUITrainer(randomName(), randomGender(), randomAge()));

    // run the school
    school.aDayAtSchool();

    // free instructors have 20% chance of leaving the school
    for (Instructor instructor: school.getInstructors()) {
      if (instructor.getAssignedCourse() == null && getProbability(20)) {
        school.remove(instructor);
      }
    }

    // students that have obtained all certificates can leave the school
    for (Student student: school.getStudents()) {
      // unenrolled students have 5% chance of leaving
      if (student.isFree() && getProbability(5)) {
        school.remove(student);
      } else {
        // check if student hasAll certificates
        Boolean hasAll = true;
        for (Subject subject: school.getSubjects()) {
          if (!student.hasCertificate(subject)) hasAll = false;
        }
        // if yes, remove the student from the school
        if (hasAll) {
          school.remove(student);
        }
      }
    }

    // clear previous state
    System.out.print("\033[H\033[2J");  
    System.out.flush();
    // print school state
    System.out.println(school.toString() + "\n");

    System.out.println("Courses:");
    for (Course course: school.getCourses()) {
      System.out.println("\t" + course.toString());
    }

    System.out.println("Students:");
    for (Student student: school.getStudents()) {
      System.out.println("\t" + student.toString());
    }

    System.out.println("Instructors: ");
    for (Instructor instructor: school.getInstructors()) {
      System.out.println("\t" + instructor.toString());
    }
  }

  // generates a random UUID string
  private String randomName() {
    return UUID.randomUUID().toString().split("-")[0];
  }

  // generates a random gender char
  private char randomGender() {
    Boolean isMale = toolbox.getRandomInteger(2) == 2;
    return isMale ? 'M' : 'F';
  }

  // generates a random age between 18 and 55
  private Integer randomAge() {
    return toolbox.getRandomInteger(55 - 18) + 18;
  }

  // generates a student with a random name, gender, and age
  private Student generateStudent() {
    return new Student(randomName(), randomGender(), randomAge());
  }

  // generates probability based on a percentage
  private Boolean getProbability(Integer percentage) {
    Integer randomPercentage = toolbox.getRandomInteger(100);
    return randomPercentage <= percentage;
  }

  // generates an instructor based on the probabilities

  // overload of run
  // allows to specify the amount of days to run for
  // Thread.sleep can throw InterruptedException
  public void run(Integer days) throws InterruptedException {
    for (Integer i = 0; i < days; i++) {
      run();
      try {
        Thread.sleep(50);
      }
      catch(InterruptedException e) {
      }
    }
  }
}
