public class Carnivore extends Animal {

}
