public class Omnivore extends Animal {}
