public class Herbivore extends Animal {
}
