// Plant class
public class Plant extends Food {
  // Plant constructor that takes its name
  public Plant(String name) {
    super(name); // pass the name to the Food class constructor
  }
}
