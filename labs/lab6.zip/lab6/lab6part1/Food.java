// Food class
public class Food {
  private String name; // name property

  // Food constructor
  public Food(String name) {
    this.name = name;
  }

  // name getter
  public String getName() {
    return name;
  }

}
