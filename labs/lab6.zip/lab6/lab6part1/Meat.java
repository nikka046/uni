// Meat class
public class Meat extends Food {
  // Meat constructor
  public Meat(String name) {
    super(name); // pass the name to the food class constructor
  }
}
